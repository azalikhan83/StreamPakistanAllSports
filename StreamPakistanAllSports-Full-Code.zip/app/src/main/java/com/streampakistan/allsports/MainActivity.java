package com.streampakistan.allsports;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MainActivity extends Activity {
    private static final String API = "https://stream-pakistan-api.azalikhan83.workers.dev/api/channels";
    private LinearLayout content;
    private TextView status;
    private final int bg = Color.rgb(9, 15, 32);
    private final int accent = Color.rgb(0, 211, 170);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(22, 32, 22, 16);
        TextView heading = new TextView(this);
        heading.setText("STREAM PAKISTAN\nALL SPORTS");
        heading.setTextColor(Color.WHITE);
        heading.setTypeface(null, Typeface.BOLD);
        heading.setTextSize(27);
        root.addView(heading);
        TextView tagline = new TextView(this);
        tagline.setText("LIVE SPORTS  •  CRICKET  •  FOOTBALL");
        tagline.setTextColor(accent);
        tagline.setTextSize(12);
        tagline.setPadding(0, 10, 0, 14);
        root.addView(tagline);
        Button refresh = new Button(this);
        refresh.setText("REFRESH CHANNELS");
        refresh.setOnClickListener(v -> loadChannels());
        root.addView(refresh);
        status = new TextView(this);
        status.setTextColor(Color.LTGRAY);
        status.setPadding(0, 16, 0, 12);
        root.addView(status);
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView footer = new TextView(this);
        footer.setText("Only licensed and authorized streams");
        footer.setTextColor(Color.GRAY);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer);
        setContentView(root);
        loadChannels();
    }

    private void loadChannels() {
        status.setText("Loading channels...");
        content.removeAllViews();
        new Thread(() -> {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(API).openConnection();
                conn.setConnectTimeout(12000);
                conn.setReadTimeout(12000);
                conn.setRequestProperty("Accept", "application/json");
                if (conn.getResponseCode() != 200) throw new Exception("Server returned " + conn.getResponseCode());
                StringBuilder json = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) json.append(line);
                } finally { conn.disconnect(); }
                JSONObject response = new JSONObject(json.toString());
                if (!response.optBoolean("success", false)) throw new Exception("API did not return success");
                JSONArray channels = response.optJSONArray("channels");
                if (channels == null) channels = new JSONArray();
                final JSONArray result = channels;
                runOnUiThread(() -> showChannels(result));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("Connection error: " + e.getMessage()));
            }
        }).start();
    }

    private void showChannels(JSONArray channels) {
        content.removeAllViews();
        status.setText(channels.length() + " active channels");
        if (channels.length() == 0) {
            addMessage("No active channels yet. Add an authorized channel in your Cloudflare admin API.");
            return;
        }
        for (int i = 0; i < channels.length(); i++) {
            JSONObject channel = channels.optJSONObject(i);
            if (channel == null) continue;
            String name = channel.optString("name", "Sports Channel");
            String category = channel.optString("category", "Sports");
            String stream = channel.optString("stream_url", "");
            Button item = new Button(this);
            item.setAllCaps(false);
            item.setText("▶  " + name + "\n" + category);
            item.setTextColor(Color.WHITE);
            item.setBackgroundColor(Color.rgb(22, 39, 63));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
            params.bottomMargin = 12;
            content.addView(item, params);
            item.setOnClickListener(v -> {
                if (!stream.startsWith("https://")) {
                    status.setText("Stream unavailable: API must return an authorized HTTPS stream_url.");
                } else {
                    openStream(name, stream);
                }
            });
        }
    }

    private void addMessage(String text) {
        TextView message = new TextView(this);
        message.setText(text);
        message.setTextSize(17);
        message.setTextColor(Color.LTGRAY);
        message.setPadding(0, 30, 0, 20);
        content.addView(message);
    }

    private void openStream(String name, String url) {
        // Basic HTTPS webpage player only. Native HLS playback needs a dedicated player library.
        if (!url.startsWith("https://")) return;
        content.removeAllViews();
        Button back = new Button(this);
        back.setText("← BACK TO CHANNELS");
        back.setOnClickListener(v -> loadChannels());
        content.addView(back);
        status.setText(name);
        WebView player = new WebView(this);
        player.setWebViewClient(new WebViewClient());
        player.getSettings().setJavaScriptEnabled(false);
        player.getSettings().setDomStorageEnabled(false);
        content.addView(player, new LinearLayout.LayoutParams(-1, 750));
        player.loadUrl(url);
    }
}
